import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ArithmeticImpl extends UnicastRemoteObject implements Arithmetic {

    public ArithmeticImpl() throws RemoteException {
        super();
    }

    @Override
    public double add(double... operands) throws RemoteException {
        double result = 0;
        for (double operand : operands) {
            result += operand;
        }
        return result;
    }

    @Override
    public double subtract(double... operands) throws RemoteException {
        if (operands.length == 0) {
            throw new RemoteException("Subtract operation requires at least one operand.");
        }
        double result = operands[0];
        for (int i = 1; i < operands.length; i++) {
            result -= operands[i];
        }
        return result;
    }

    @Override
    public double multiply(double... operands) throws RemoteException {
        double result = 1;
        for (double operand : operands) {
            result *= operand;
        }
        return result;
    }

    @Override
    public double divide(double... operands) throws RemoteException {
        if (operands.length == 0) {
            throw new RemoteException("Divide operation requires at least one operand.");
        }
        double result = operands[0];
        for (int i = 1; i < operands.length; i++) {
            if (operands[i] == 0) {
                throw new RemoteException("Cannot divide by zero.");
            }
            result /= operands[i];
        }
        return result;
    }
}