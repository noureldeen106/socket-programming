import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
public class ArithmeticClient {

    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost");
            Arithmetic arithmetic = (Arithmetic) registry.lookup("Arithmetic");

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.print("Enter an arithmetic expression  ");
                String expression = scanner.nextLine().replaceAll("\\s", "");
                String[] parts = expression.split("[+\\-*/]"); //bndkhlo fy loop
                String[] operators = expression.split("[0-9]+"); // dy t7t mdkhlnha fy loop`

                double[] operands = new double[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    try {
                        operands[i] = Double.parseDouble(parts[i]);
                    } catch (NumberFormatException e) {
                        throw new RemoteException("Invalid operand: " + parts[i]);
                    }
                }

                double result = operands[0];
                for (int i = 1; i < operands.length; i++) {
                    switch (operators[i]) {
                        case "+":
                            result = arithmetic.add(result, operands[i]);
                            break;
                        case "-":
                            result = arithmetic.subtract(result, operands[i]);
                            break;
                        case "*":
                            result = arithmetic.multiply(result, operands[i]);
                            break;
                        case "/":
                            result = arithmetic.divide(result, operands[i]);
                            break;
                        default:
                            throw new RemoteException("Invalid operator: " + operators[i]);
                    }
                }

                System.out.println("Result: " + result);
            }
        } catch (Exception e) {
            System.err.println("Arithmetic client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}