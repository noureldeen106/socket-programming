import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ArithmeticServer {

    public static void main(String[] args) {
        try {
            ArithmeticImpl arithmetic = new ArithmeticImpl();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.rebind("Arithmetic", arithmetic);
            System.out.println("Arithmetic server is running.");
        } catch (Exception e) {
            System.err.println("Arithmetic server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
