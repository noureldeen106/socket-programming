import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Arithmetic extends Remote {
    double add(double... operands) throws RemoteException;
    double subtract(double... operands) throws RemoteException;
    double multiply(double... operands) throws RemoteException;
    double divide(double... operands) throws RemoteException;
}